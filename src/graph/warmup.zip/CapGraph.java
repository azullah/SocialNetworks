/**
 *
 */
package graph;
import util.GraphLoader;

import java.util.*;


/**
 * @author Your name here.
 *
 * For the warm up assignment, you must implement your Graph in a class
 * named CapGraph.  Here is the stub file.
 *
 */
public class CapGraph implements Graph {

	/* (non-Javadoc)
	 * @see graph.Graph#addVertex(int)
	 */
	private HashMap<Integer, HashSet<Integer>> adjListsMap = new HashMap<Integer, HashSet<Integer>>();



	@Override
	public void addVertex(int num) {
		// TODO Auto-generated method stub
		if (adjListsMap.get(num) == null){
			HashSet<Integer> neighbors = new HashSet<Integer>();
			adjListsMap.put(num,  neighbors);
		}

	}

	/* (non-Javadoc)
	 * @see graph.Graph#addEdge(int, int)
	 */
	@Override
	public void addEdge(int from, int to) {
		// TODO Auto-generated method stub
		adjListsMap.get(from).add(to);
	}

	/* (non-Javadoc)
	 * @see graph.Graph#getEgonet(int)
	 */
	@Override
	public Graph getEgonet(int center) {
		// TODO Auto-generated method stub
		CapGraph egoGraph = new CapGraph();
		// Add the immediate neighbors of the center
		HashSet neighbors = adjListsMap.get(center);
		if (neighbors == null){
			return null;
		} else
		{
			egoGraph.addVertex(center);
			Iterator<Integer> iter = neighbors.iterator();
			while (iter.hasNext()){
				int friend = iter.next();
				egoGraph.addEdge(center,friend);
				egoGraph.addVertex(friend);
				// find any edges between neighbors of the center
				HashSet egoFriends = adjListsMap.get(friend);
				if (egoFriends != null ){
					Iterator<Integer> egoIter = egoFriends.iterator();
					while (egoIter.hasNext()){
						int egoFriendNext = egoIter.next();
						if (neighbors.contains(egoFriendNext)){
							egoGraph.addEdge(friend,egoFriendNext);

						}
					}
				}


			}

		}


		return egoGraph;
	}

	/* (non-Javadoc)
	 * @see graph.Graph#getSCCs()
	 */
	@Override
	public List<Graph> getSCCs() {
		// TODO Auto-generated method stub
		List<Graph> outG = new ArrayList<Graph>();
		Stack<Integer> vertices = new Stack<Integer>();
		for (int v : adjListsMap.keySet()){
			vertices.push(v);
		}
		Stack<Integer> step1_vertices = dfs(this,vertices);
		CapGraph GT = transposeGraph();
		dfs2(GT,step1_vertices,outG);


		return outG;
	}

	/* Depth first search - First time
	 *
	 */
	public Stack<Integer> dfs(Graph G, Stack<Integer> vertices){
		HashSet<Integer> visited = new HashSet<Integer>();
		Stack<Integer> finished = new Stack<Integer>();
		while (!vertices.empty()){
			int v = vertices.pop();
			if (!visited.contains(v)){
				dfsVisit(G,v,visited,finished);
			}
		}
		return finished;
	}

	/* Depth first search - 2nd time
	 *
	 */
	public void dfs2(CapGraph GT, Stack<Integer> vertices, List<Graph> outG){
		HashSet<Integer> visited = new HashSet<Integer>();
		while (!vertices.empty()){
			int v = vertices.pop();
			CapGraph sccGraph = new CapGraph();
			if (!visited.contains(v)){
				dfsVisit2(GT,v,visited,sccGraph);
			}
			if (sccGraph.getNumVertices() > 0){
				outG.add(sccGraph);
			}
		}
	}

	public void dfsVisit(Graph G, int v, HashSet<Integer> visit, Stack<Integer> finish){
		visit.add(v);
		HashSet<Integer> neighbors = getNeighbors(v);
		if (neighbors!=null){
			for (int n : neighbors){
				if (!visit.contains(n)){
					dfsVisit(G,n,visit,finish);
				}
			}
			finish.push(v);
		}
	}

	public void dfsVisit2(CapGraph GT, int v, HashSet<Integer> visit, Graph scc){
		visit.add(v);
		HashSet<Integer> neighbors = GT.getNeighbors(v);
		if (neighbors!=null){
			for (int n : neighbors){
				if (!visit.contains(n)){
					dfsVisit2(GT,n,visit,scc);
				}
			}
			scc.addVertex(v);
		}
	}

	public HashSet<Integer> getNeighbors(int v){
		HashSet<Integer> neighbors = adjListsMap.get(v);
		return neighbors;
	}

	public CapGraph transposeGraph(){
		CapGraph GT = new CapGraph();
		for (int i : adjListsMap.keySet()){
			HashSet<Integer> neighbors = getNeighbors(i);
			Iterator<Integer> iter = neighbors.iterator();
			while (iter.hasNext()){
				int friend = iter.next();
				GT.addVertex(friend);
				GT.addEdge(friend,i);
			}
			GT.addVertex(i);
		}
		return GT;
	}
	/* (non-Javadoc)
	 * @see graph.Graph#exportGraph()
	 */
	@Override
	public HashMap<Integer, HashSet<Integer>> exportGraph() {
		// TODO Auto-generated method stub
		return adjListsMap;
	}

	public String printGraph(){
		String s = "";
		s += " (size " + getNumVertices() + "+" + getNumEdges() + " Graph nodes and edges ):";

		for (int k : adjListsMap.keySet()){
			s += "\n\t" + k + " ==> ";
			for (int v : adjListsMap.get(k)){
				s += "\t" + v;
			}
		}
		return s;

	}

	public int getNumVertices()
	{
		return adjListsMap.keySet().size();
	}

	public int getNumEdges()
	{
		int numEdges = 0;
		for (int k : adjListsMap.keySet()){
			for (int v : adjListsMap.get(k)){
				numEdges++;
			}
		}
		return numEdges;
	}

	public static void main(String[] args)
	{
		System.out.print("Making a new Graph...");
		CapGraph theGraph = new CapGraph();
		System.out.print("DONE. \nLoading the Graph...");
		GraphLoader.loadGraph(theGraph,"data/scc/test_4.txt");
		System.out.println(theGraph.printGraph());
		System.out.println("End printing graph");
		Graph TGraph = new CapGraph();
		TGraph = theGraph.transposeGraph();
		System.out.println(TGraph.printGraph());
		System.out.println("End printing Transpose graph");

		List<Graph> sccGraphList = theGraph.getSCCs();
		Iterator<Graph> sccIter = sccGraphList.iterator();
		int i = 0;
		while (sccIter.hasNext()){
			i++;
			Graph sccGraph = sccIter.next();
			System.out.println(sccGraph.printGraph());
			System.out.println("End sub-graph: " + i);
		}
		System.out.println("DONE.");

	}

}
